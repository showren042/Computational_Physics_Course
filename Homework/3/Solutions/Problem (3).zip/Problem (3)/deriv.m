
function F=deriv(x,t,params)
    F=[x(2),x(3),(1-6*x(1))*x(2)];
end