
function F=deriv(x,t,params)
    F=[x(2),-x(1)];
end